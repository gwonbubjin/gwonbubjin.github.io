// 확장 프로그램 아이콘 클릭 시 사이드패널을 여는 이벤트 리스너
chrome.action.onClicked.addListener(async (tab) => {
  // 사이드패널 열기
  await chrome.sidePanel.open({ tabId: tab.id });
  
  // 사이드패널 포커스 설정
  await chrome.sidePanel.setOptions({
    tabId: tab.id,
    path: 'sidepanel.html',
    enabled: true
  });
}); 