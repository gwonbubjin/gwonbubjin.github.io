document.addEventListener('DOMContentLoaded', () => {
  // DOM 요소
  const loginContainer = document.getElementById('login-container');
  const passwordSetup = document.getElementById('password-setup');
  const passwordLogin = document.getElementById('password-login');
  const memoContainer = document.getElementById('memo-container');
  const setupPasswordInput = document.getElementById('setup-password');
  const confirmPasswordInput = document.getElementById('confirm-password');
  const savePasswordBtn = document.getElementById('save-password-btn');
  const loginPasswordInput = document.getElementById('login-password');
  const loginBtn = document.getElementById('login-btn');
  const lockBtn = document.getElementById('lock-btn');
  const memoTitleInput = document.getElementById('memo-title');
  const memoContentInput = document.getElementById('memo-content');
  const addMemoBtn = document.getElementById('add-memo-btn');
  const updateMemoBtn = document.getElementById('update-memo-btn');
  const cancelEditBtn = document.getElementById('cancel-edit-btn');
  const memoList = document.getElementById('memo-list');
  
  // 모달 창 요소
  const memoModal = document.getElementById('memo-modal');
  const modalTitle = document.getElementById('modal-title');
  const modalContent = document.getElementById('modal-content');
  const modalDate = document.getElementById('modal-date');
  const modalClose = document.getElementById('modal-close');

  // 상태 변수
  let currentEditingId = null;
  let memos = [];
  let deletingMemoId = null; // 삭제 중인 메모 ID 저장용

  // 초기화 함수
  function init() {
    const hasPassword = localStorage.getItem('memolock_password') !== null;
    
    if (hasPassword) {
      passwordSetup.classList.add('hidden');
      passwordLogin.classList.remove('hidden');
    } else {
      passwordSetup.classList.remove('hidden');
      passwordLogin.classList.add('hidden');
    }

    // 이벤트 리스너 등록
    savePasswordBtn.addEventListener('click', setupPassword);
    loginBtn.addEventListener('click', login);
    lockBtn.addEventListener('click', lock);
    addMemoBtn.addEventListener('click', addMemo);
    updateMemoBtn.addEventListener('click', updateMemo);
    cancelEditBtn.addEventListener('click', cancelEdit);
    
    // 모달 창 닫기 이벤트 리스너
    modalClose.addEventListener('click', closeModal);
    
    // 모달 바깥 영역 클릭 시 닫기
    window.addEventListener('click', (e) => {
      if (e.target === memoModal) {
        closeModal();
      }
    });
    
    // ESC 키로 모달 닫기
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && !memoModal.classList.contains('hidden')) {
        closeModal();
      }
    });
  }

  // 비밀번호 설정
  function setupPassword() {
    const password = setupPasswordInput.value;
    const confirmPassword = confirmPasswordInput.value;

    if (password.trim() === '') {
      alert('비밀번호를 입력해주세요.');
      return;
    }

    if (password !== confirmPassword) {
      alert('비밀번호가 일치하지 않습니다.');
      return;
    }

    // 비밀번호 저장 (실제 구현에서는 해싱 고려)
    localStorage.setItem('memolock_password', password);
    
    // UI 전환
    passwordSetup.classList.add('hidden');
    passwordLogin.classList.remove('hidden');
    setupPasswordInput.value = '';
    confirmPasswordInput.value = '';
  }

  // 로그인 (잠금 해제)
  function login() {
    const password = loginPasswordInput.value;
    const savedPassword = localStorage.getItem('memolock_password');

    if (password === savedPassword) {
      loginContainer.classList.add('hidden');
      memoContainer.classList.remove('hidden');
      loginPasswordInput.value = '';
      
      // 저장된 메모 불러오기
      loadMemos();
    } else {
      alert('비밀번호가 일치하지 않습니다.');
    }
  }

  // 잠금
  function lock() {
    memoContainer.classList.add('hidden');
    loginContainer.classList.remove('hidden');
    resetForm();
  }

  // 메모 불러오기
  function loadMemos() {
    const savedMemos = localStorage.getItem('memolock_memos');
    if (savedMemos) {
      memos = JSON.parse(savedMemos);
      renderMemos();
    } else {
      memos = [];
      memoList.innerHTML = '<p class="empty-message">저장된 메모가 없습니다.</p>';
    }
  }

  // 메모 렌더링
  function renderMemos() {
    if (memos.length === 0) {
      memoList.innerHTML = '<p class="empty-message">저장된 메모가 없습니다.</p>';
      return;
    }

    memoList.innerHTML = '';
    memos.forEach(memo => {
      const memoCard = document.createElement('div');
      memoCard.className = 'memo-card';
      memoCard.dataset.id = memo.id; // 메모 ID를 dataset에 저장
      memoCard.innerHTML = `
        <h3>${memo.title}</h3>
        <p>${formatContent(memo.content, 100)}</p>
        <div class="card-actions">
          <button class="edit-btn" data-id="${memo.id}">✏️ 수정</button>
          <button class="delete-btn" data-id="${memo.id}">🗑️ 삭제</button>
        </div>
      `;
      
      // 카드 클릭 이벤트 추가 (수정/삭제 버튼 제외)
      memoCard.addEventListener('click', (e) => {
        // 버튼 클릭 시 모달 실행 방지
        if (!e.target.closest('.card-actions')) {
          openMemoDetail(memo);
        }
      });
      
      memoList.appendChild(memoCard);
    });

    // 수정/삭제 버튼 이벤트 리스너 등록
    document.querySelectorAll('.edit-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const id = e.target.dataset.id;
        editMemo(id);
      });
    });

    document.querySelectorAll('.delete-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation(); // 이벤트 버블링 방지
        const id = e.target.dataset.id;
        deleteMemo(id);
      });
    });
  }
  
  // 메모 내용 일부만 표시 (글자 수 제한)
  function formatContent(content, maxLength) {
    if (content.length <= maxLength) return content;
    return content.substring(0, maxLength) + '...';
  }
  
  // 메모 상세 보기 모달 열기
  function openMemoDetail(memo) {
    modalTitle.textContent = memo.title;
    modalContent.textContent = memo.content;
    
    // 날짜 표시 (생성일 또는 수정일)
    const dateStr = memo.updatedAt ? 
      `수정: ${formatDate(memo.updatedAt)}` : 
      `생성: ${formatDate(memo.createdAt)}`;
    modalDate.textContent = dateStr;
    
    // 모달 표시
    memoModal.classList.remove('hidden');
  }
  
  // 날짜 포맷팅
  function formatDate(dateStr) {
    const date = new Date(dateStr);
    return `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')} ${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
  }
  
  // 모달 닫기
  function closeModal() {
    memoModal.classList.add('hidden');
  }

  // 메모 추가
  function addMemo() {
    const title = memoTitleInput.value.trim();
    const content = memoContentInput.value.trim();

    if (title === '' || content === '') {
      alert('제목과 내용을 모두 입력해주세요.');
      return;
    }

    const newMemo = {
      id: Date.now().toString(), // 고유 ID
      title,
      content,
      createdAt: new Date().toISOString()
    };

    memos.push(newMemo);
    saveMemos();
    resetForm();
  }

  // 메모 수정 모드 진입
  function editMemo(id) {
    const memo = memos.find(m => m.id === id);
    if (!memo) return;

    memoTitleInput.value = memo.title;
    memoContentInput.value = memo.content;
    currentEditingId = id;

    // UI 업데이트
    addMemoBtn.classList.add('hidden');
    updateMemoBtn.classList.remove('hidden');
    cancelEditBtn.classList.remove('hidden');
  }

  // 메모 업데이트
  function updateMemo() {
    if (!currentEditingId) return;

    const title = memoTitleInput.value.trim();
    const content = memoContentInput.value.trim();

    if (title === '' || content === '') {
      alert('제목과 내용을 모두 입력해주세요.');
      return;
    }

    const index = memos.findIndex(m => m.id === currentEditingId);
    if (index !== -1) {
      memos[index].title = title;
      memos[index].content = content;
      memos[index].updatedAt = new Date().toISOString();

      saveMemos();
      resetForm();
    }
  }

  // 메모 삭제 - 개선된 버전
  function deleteMemo(id) {
    // 이미 다른 메모를 삭제 중인 경우 무시
    if (deletingMemoId) return;
    
    // 삭제할 메모 카드 요소 찾기
    const memoCard = document.querySelector(`.memo-card[data-id="${id}"]`);
    if (!memoCard) return;
    
    // 현재 삭제 중인 메모 ID 저장
    deletingMemoId = id;
    
    // 삭제 애니메이션 클래스 추가
    memoCard.classList.add('deleting');
    
    // 삭제 이펙트 표시
    const deleteEffect = document.createElement('div');
    deleteEffect.className = 'delete-effect';
    memoCard.appendChild(deleteEffect);
    
    // 애니메이션 완료 후 실제 삭제 수행 (500ms 후)
    setTimeout(() => {
      // 메모 배열에서 제거
      memos = memos.filter(memo => memo.id !== id);
      
      // 로컬 스토리지에 저장
      localStorage.setItem('memolock_memos', JSON.stringify(memos));
      
      // 삭제 완료 후 UI 갱신 (애니메이션 유지를 위해 직접 요소 제거)
      memoCard.addEventListener('animationend', () => {
        memoCard.remove();
        
        // 모든 메모가 삭제된 경우 빈 메시지 표시
        if (memos.length === 0) {
          memoList.innerHTML = '<p class="empty-message">저장된 메모가 없습니다.</p>';
        }
        
        // 삭제 중인 ID 초기화
        deletingMemoId = null;
      });
      
      memoCard.classList.add('removing');
    }, 300);
  }

  // 수정 취소
  function cancelEdit() {
    resetForm();
  }

  // 폼 초기화
  function resetForm() {
    memoTitleInput.value = '';
    memoContentInput.value = '';
    currentEditingId = null;
    
    // UI 업데이트
    addMemoBtn.classList.remove('hidden');
    updateMemoBtn.classList.add('hidden');
    cancelEditBtn.classList.add('hidden');
  }

  // 메모 저장
  function saveMemos() {
    localStorage.setItem('memolock_memos', JSON.stringify(memos));
    renderMemos();
  }

  // 초기화 실행
  init();
}); 